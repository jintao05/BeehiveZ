package headliner.treedistance;

public class BasicIdentity extends TreeEditOperation {

	@Override
	public double getCost(int nodeID, int nodeID2, TreeDefinition tree,
			TreeDefinition tree2) {
		// TODO Auto-generated method stub
		return 0;
	}

}
